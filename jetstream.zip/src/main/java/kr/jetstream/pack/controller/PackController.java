package kr.jetstream.pack.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class PackController {
	@RequestMapping("/pack.do")
	public ModelAndView showPack(String board_id){		
		return new ModelAndView("board/list", "board_id", board_id);
	}
}
