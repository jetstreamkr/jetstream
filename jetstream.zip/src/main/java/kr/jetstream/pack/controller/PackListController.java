package kr.jetstream.pack.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import kr.jetstream.pack.dto.PackDTO;
import kr.jetstream.pack.service.PackService;

@Controller
public class PackListController {
	@Autowired
	PackService service;
	
	@RequestMapping(value="/board/board_list.do")
	public ModelAndView packList(String board_id){
		List<PackDTO> packList = service.packList(board_id);
		System.out.println(packList.toString());
		return new ModelAndView("board/list","packList",packList);
		
	}
	
}
