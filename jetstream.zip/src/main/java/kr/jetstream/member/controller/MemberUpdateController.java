package kr.jetstream.member.controller;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.util.WebUtils;

import kr.jetstream.member.dto.MemberDTO;
import kr.jetstream.member.dto.PhotoDTO;
import kr.jetstream.member.service.MemberService;

@Controller
public class MemberUpdateController {

	@Autowired
	MemberService service;

	@RequestMapping(value = "memberupdate.do", method = RequestMethod.GET)
	public String showpage() {
		return "member/update";
	}

	@RequestMapping(value = "memberupdate.do", method = RequestMethod.POST)
	public ModelAndView fileUpload(HttpSession session, PhotoDTO photo, 
			@RequestParam("file") MultipartFile file, HttpServletRequest req) {
		
		ModelAndView mav = new ModelAndView();
		MemberDTO dto = (MemberDTO) session.getAttribute("member");
		String email = dto.getEmail();
		String member_nm = dto.getMember_nm();
		String initial = member_nm.substring(0, 1);
		
		FileOutputStream fos = null;
		long time = System.currentTimeMillis(); 
		String filename = time + file.getOriginalFilename();


		try {
			String path = WebUtils.getRealPath(req.getSession().getServletContext(),
					"/resources/images");
			File f = new File(path +"/"+ filename);
			file.transferTo(f);
			
		} catch (IllegalStateException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		service.update(filename, email);
		dto.setPhoto(filename);
		session.removeAttribute("member");
		session.setAttribute("member", dto);
		mav.setViewName("dashboard");
		return mav;
	}

}
